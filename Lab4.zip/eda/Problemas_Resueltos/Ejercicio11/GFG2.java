package Problemas_Resueltos.Ejercicio11;
import java.util.LinkedList; 
public class GFG2 {
    public static void main(String args[]) { 
  LinkedList<String> list = new LinkedList<String>(); 
  list.add("Uno, Dos, Tres "); 
  list.add("Cuatro "); 
  // Mostrar el tamaño de la lista 
  System.out.println("El tamaño de la lista es: " + list.size()); 
 } 
} 